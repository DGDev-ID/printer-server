module.exports = {
  PORT: 3000,

  PRINTERS: {
    // Printer atas: hanya BEVERAGE
    top: {
      ip: "192.168.1.250",
      label: "Kitchen Printer (Beverage)",
    },
    // Printer bawah: semua menu
    bottom: {
      ip: "192.168.1.251",
      label: "Cashier Printer (All Items)",
    },
  },

  PRINTER_PORT: 9100,
  PRINTER_TIMEOUT_MS: 3000,

  // Lebar kertas thermal (karakter)
  PAPER_WIDTH: 32,
};
