const net = require("net");
const { PRINTER_PORT, PRINTER_TIMEOUT_MS, PAPER_WIDTH } = require("./config");

// ─── ESC/POS Constants ────────────────────────────────────────────────────────
const ESC = "\x1B";
const GS = "\x1D";

const CMD = {
  INIT: ESC + "@",
  ALIGN_CENTER: ESC + "a" + "\x01",
  ALIGN_LEFT: ESC + "a" + "\x00",
  ALIGN_RIGHT: ESC + "a" + "\x02",
  BOLD_ON: ESC + "E" + "\x01",
  BOLD_OFF: ESC + "E" + "\x00",
  DOUBLE_HEIGHT_ON: ESC + "!" + "\x10",
  DOUBLE_HEIGHT_OFF: ESC + "!" + "\x00",
  FEED: ESC + "d" + "\x04",
  CUT: GS + "V" + "\x00",
};

// ─── Formatter Helpers ────────────────────────────────────────────────────────
const LINE = "=".repeat(PAPER_WIDTH);
const DASH = "-".repeat(PAPER_WIDTH);

function center(text, width = PAPER_WIDTH) {
  if (text.length >= width) return text;
  const pad = Math.floor((width - text.length) / 2);
  return " ".repeat(pad) + text;
}

function leftRight(left, right, width = PAPER_WIDTH) {
  const gap = width - left.length - right.length;
  if (gap <= 0) return left + " " + right;
  return left + " ".repeat(gap) + right;
}

function formatCurrency(value) {
  return "Rp " + parseInt(value).toLocaleString("id-ID");
}

function formatDate(isoString) {
  const d = new Date(isoString);
  return d.toLocaleString("id-ID", {
    timeZone: "Asia/Jakarta",
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

// ─── Build Receipt String ─────────────────────────────────────────────────────

/**
 * Builds ESC/POS receipt string.
 * @param {object} trx - Transaction data
 * @param {"top"|"bottom"} printerType
 * @returns {string}
 */
function buildReceipt(trx, printerType) {
  const isTop = printerType === "top";

  // Filter items based on printer type
  const items = isTop
    ? trx.details.filter((d) => d.menu?.menu_type === "BEVERAGE")
    : trx.details;

  if (items.length === 0) {
    return null; // Nothing to print for this printer
  }

  let r = "";

  r += CMD.INIT;

  // ── Header ──────────────────────────────────────────────────────────────────
  r += CMD.ALIGN_CENTER;
  r += CMD.BOLD_ON;
  r += CMD.DOUBLE_HEIGHT_ON;
  r += center(trx.cafe?.name || "CAFE") + "\n";
  r += CMD.DOUBLE_HEIGHT_OFF;
  r += CMD.BOLD_OFF;

  if (trx.cafe?.address) {
    // Wrap address to fit paper width
    const words = trx.cafe.address.split(" ");
    let line = "";
    for (const word of words) {
      if ((line + " " + word).trim().length > PAPER_WIDTH) {
        r += center(line.trim()) + "\n";
        line = word;
      } else {
        line = (line + " " + word).trim();
      }
    }
    if (line) r += center(line) + "\n";
  }

  r += "\n";
  r += CMD.ALIGN_LEFT;
  r += LINE + "\n";

  // ── Transaction Info ─────────────────────────────────────────────────────────
  r += leftRight("No:", trx.unique_code.slice(-10)) + "\n";
  r += leftRight("Tanggal:", formatDate(trx.created_at)) + "\n";
  r += leftRight("Meja:", trx.table?.name || "-") + "\n";
  r += leftRight("Pelanggan:", trx.cust_name || "-") + "\n";

  if (isTop) {
    r += CMD.ALIGN_CENTER;
    r += "[ MINUMAN / BEVERAGE ]\n";
    r += CMD.ALIGN_LEFT;
  }

  r += LINE + "\n";

  // ── Items ────────────────────────────────────────────────────────────────────
  let subtotal = 0;

  for (const item of items) {
    const menuName = item.menu?.name || "Menu";
    const qty = item.amount;
    const price = parseFloat(item.price);
    const itemTotal = qty * price;
    subtotal += itemTotal;

    // Line 1: Nama menu
    r += CMD.BOLD_ON;
    r += menuName + "\n";
    r += CMD.BOLD_OFF;

    // Line 2: Qty x Harga = Total
    const qtyPrice = `  ${qty} x ${formatCurrency(price)}`;
    const totalStr = formatCurrency(itemTotal);
    r += leftRight(qtyPrice, totalStr) + "\n";

    // Variants (if any)
    if (item.selected_variants && item.selected_variants.length > 0) {
      for (const v of item.selected_variants) {
        r += "  * " + v.name + "\n";
      }
    }

    // Description (if any)
    if (item.description) {
      r += "  Ket: " + item.description + "\n";
    }
  }

  r += DASH + "\n";

  // ── Totals (only on bottom/cashier printer) ──────────────────────────────────
  if (!isTop) {
    r += leftRight("Subtotal:", formatCurrency(trx.price)) + "\n";

    if (parseFloat(trx.fee) > 0) {
      r += leftRight("Biaya Layanan:", formatCurrency(trx.fee)) + "\n";
    }

    r += CMD.BOLD_ON;
    r += LINE + "\n";
    r += leftRight("TOTAL:", formatCurrency(trx.total_price)) + "\n";
    r += LINE + "\n";
    r += CMD.BOLD_OFF;

    // Payment info
    const paymentLabel =
      trx.payment_type === "manual" ? "Tunai/Manual" : trx.payment_type;
    r += leftRight("Pembayaran:", paymentLabel) + "\n";
    r += leftRight(
      "Status:",
      trx.status === "success" ? "LUNAS" : trx.status.toUpperCase()
    ) + "\n";
  } else {
    // On top/kitchen printer, just show beverage subtotal
    r += CMD.BOLD_ON;
    r += leftRight("Total Minuman:", formatCurrency(subtotal)) + "\n";
    r += CMD.BOLD_OFF;
  }

  // ── Footer ───────────────────────────────────────────────────────────────────
  r += "\n";
  r += CMD.ALIGN_CENTER;
  r += "Terima kasih!\n";
  r += "Selamat menikmati :)\n";
  r += "\n";

  r += CMD.FEED;
  r += CMD.CUT;

  return r;
}

// ─── Send to Printer ──────────────────────────────────────────────────────────

/**
 * Sends ESC/POS data to printer via TCP.
 * @param {string} ip - Printer IP address
 * @param {string} data - ESC/POS string
 * @returns {Promise<{success: boolean, message: string}>}
 */
function sendToPrinter(ip, data) {
  return new Promise((resolve) => {
    const client = new net.Socket();
    let settled = false;

    const done = (result) => {
      if (settled) return;
      settled = true;
      client.destroy();
      resolve(result);
    };

    client.setTimeout(PRINTER_TIMEOUT_MS);

    client.connect(PRINTER_PORT, ip, () => {
      client.write(data, "binary", () => {
        setTimeout(() => {
          done({ success: true, message: `Print sent to ${ip}` });
        }, 500);
      });
    });

    client.on("timeout", () => {
      done({ success: false, message: `Timeout connecting to ${ip}` });
    });

    client.on("error", (err) => {
      done({ success: false, message: `Error on ${ip}: ${err.message}` });
    });
  });
}

module.exports = { buildReceipt, sendToPrinter };
