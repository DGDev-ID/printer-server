const express = require("express");
const { PRINTERS, PORT } = require("./config");
const { buildReceipt, sendToPrinter } = require("./printer");

const app = express();
app.use(express.json());

// ─────────────────────────────────────────────────────────────────────────────
// POST /print
// Body: transaction JSON (sesuai format dari sistem)
// ─────────────────────────────────────────────────────────────────────────────
app.post("/print", async (req, res) => {
  const trx = req.body;

  // Basic validation
  if (!trx || !trx.id || !trx.details || !Array.isArray(trx.details)) {
    return res.status(400).json({
      success: false,
      message: "Invalid transaction data. Pastikan field id dan details ada.",
    });
  }

  const results = {};

  // ── Top Printer: BEVERAGE only ──────────────────────────────────────────────
  const topReceipt = buildReceipt(trx, "top");
  if (topReceipt) {
    console.log(`[PRINT] Sending to TOP printer (${PRINTERS.top.ip})...`);
    results.top = await sendToPrinter(PRINTERS.top.ip, topReceipt);
  } else {
    results.top = { success: false, message: "No BEVERAGE items to print." };
  }

  // ── Bottom Printer: All items ───────────────────────────────────────────────
  const bottomReceipt = buildReceipt(trx, "bottom");
  if (bottomReceipt) {
    console.log(`[PRINT] Sending to BOTTOM printer (${PRINTERS.bottom.ip})...`);
    results.bottom = await sendToPrinter(PRINTERS.bottom.ip, bottomReceipt);
  } else {
    results.bottom = { success: false, message: "No items to print." };
  }

  const allSuccess = results.top.success && results.bottom.success;

  return res.status(allSuccess ? 200 : 207).json({
    success: allSuccess,
    transaction_id: trx.id,
    unique_code: trx.unique_code,
    printers: results,
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// POST /print/top   → Hanya printer atas (BEVERAGE)
// POST /print/bottom → Hanya printer bawah (semua item)
// ─────────────────────────────────────────────────────────────────────────────
app.post("/print/:target", async (req, res) => {
  const { target } = req.params;

  if (!["top", "bottom"].includes(target)) {
    return res.status(404).json({ success: false, message: "Endpoint tidak ditemukan. Gunakan /print/top atau /print/bottom" });
  }

  const trx = req.body;

  if (!trx || !trx.id || !trx.details || !Array.isArray(trx.details)) {
    return res.status(400).json({
      success: false,
      message: "Invalid transaction data.",
    });
  }

  const receipt = buildReceipt(trx, target);

  if (!receipt) {
    return res.status(200).json({
      success: false,
      message:
        target === "top"
          ? "Tidak ada item BEVERAGE untuk dicetak."
          : "Tidak ada item untuk dicetak.",
    });
  }

  const printer = PRINTERS[target];
  console.log(`[PRINT] Sending to ${printer.label} (${printer.ip})...`);
  const result = await sendToPrinter(printer.ip, receipt);

  return res.status(result.success ? 200 : 500).json({
    success: result.success,
    target,
    printer_ip: printer.ip,
    transaction_id: trx.id,
    message: result.message,
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// GET /health  → Cek server jalan
// ─────────────────────────────────────────────────────────────────────────────
app.get("/health", (req, res) => {
  res.json({
    status: "ok",
    server: "Print Server",
    printers: {
      top: PRINTERS.top,
      bottom: PRINTERS.bottom,
    },
    timestamp: new Date().toISOString(),
  });
});

// ─────────────────────────────────────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`\n🖨️  Print Server running on http://localhost:${PORT}`);
  console.log(`   TOP    printer → ${PRINTERS.top.ip} (BEVERAGE only)`);
  console.log(`   BOTTOM printer → ${PRINTERS.bottom.ip} (All items)`);
  console.log(`\nEndpoints:`);
  console.log(`   POST /print          → kirim ke kedua printer`);
  console.log(`   POST /print/top      → hanya printer atas (beverage)`);
  console.log(`   POST /print/bottom   → hanya printer bawah (semua menu)`);
  console.log(`   GET  /health         → cek status server\n`);
});
